<div class="alert alert-danger">
    {{ $slot }}
</div>
