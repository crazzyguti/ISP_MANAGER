class Size {
    constructor() {
        this.width = 0;
        this.height = 0;
    }
}


class Marker {
    constructor() {
        this.name = "";
    }
}


class fontIcons {
    constructor() {
        this.classes = [];
        this.name = "";
    }
}
