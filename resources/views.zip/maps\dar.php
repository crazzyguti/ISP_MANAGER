<?php

class AdminUser {

    private $userName;
    private $userPassword;
    private $userId;
    private $error;
}

