class Marker{
    constructor(){
        this.name = "";
        this.icon = "";
    }

    create(){

    }

    read(){

    }

    update(){

    }

    delete(){

    }

}
